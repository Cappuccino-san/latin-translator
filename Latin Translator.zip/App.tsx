import LatinTranslatorPage from './app/page';
import './App.css'; // Assuming some global styles might be here, can be removed if not used by LatinTranslatorPage

function App() {
  return (
    <LatinTranslatorPage />
  );
}

export default App;

